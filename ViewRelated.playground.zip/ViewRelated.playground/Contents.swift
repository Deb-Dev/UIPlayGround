//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

extension UIView {
    public enum Side {
        case top, bottom, leading, trailing
    }
    @discardableResult
    func shadow(usingShadowOffSet offSet: CGSize,
                   shadowOpacity opcity: Float,
                   shadowRadius radius: Float,
                   shadowColor color: UIColor = .black) -> UIView {
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOpacity = opcity
        self.layer.shadowOffset = offSet
        self.layer.shadowRadius = CGFloat(radius)
        return self
    }
    
    @discardableResult
    func getRoundedCornersWithClipToBound(withCornerRadious radious: CGFloat) -> UIView {
        let roundedCornerView = UIView()
        roundedCornerView.backgroundColor = .white

        
        roundedCornerView.layer.cornerRadius = radious
        roundedCornerView.layer.masksToBounds = true
        roundedCornerView.clipsToBounds = true

        addSubview(roundedCornerView)
        roundedCornerView.translatesAutoresizingMaskIntoConstraints = false
        roundedCornerView.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        roundedCornerView.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true
        roundedCornerView.topAnchor.constraint(equalTo: topAnchor).isActive = true
        roundedCornerView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
        
        return roundedCornerView
    }
    
}

class RoundedViewWithShadow: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        addShadow()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func addShadow() {
        shadow(usingShadowOffSet: CGSize(width: 1, height: 5), shadowOpacity: 0.5, shadowRadius: 3)
        getRoundedCornersWithClipToBound(withCornerRadious: 10.0)

        
    }
    
}

class Canvas: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpUIElements()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setUpUIElements() {
        self.backgroundColor = .white
        let viewWithShadowAndRoundCorner = RoundedViewWithShadow(frame: CGRect(x: 50, y: 50, width: 200, height: 300))
        addSubview(viewWithShadowAndRoundCorner)
        
    }
}

PlaygroundPage.current.liveView = Canvas(frame: CGRect(x: 0, y: 0, width: 500, height: 800))

